# example.py - script de demonstração para Anim Grid Flow
def main():
    print("Executando demo para: Anim Grid Flow")

if __name__ == '__main__':
    main()
