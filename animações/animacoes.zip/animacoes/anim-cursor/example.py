# example.py - script de demonstração para Anim Cursor
def main():
    print("Executando demo para: Anim Cursor")

if __name__ == '__main__':
    main()
