# example.py - script de demonstração para Anim Title Slide
def main():
    print("Executando demo para: Anim Title Slide")

if __name__ == '__main__':
    main()
