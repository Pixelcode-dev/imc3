# example.py - script de demonstração para Anim Slide Right
def main():
    print("Executando demo para: Anim Slide Right")

if __name__ == '__main__':
    main()
