# example.py - script de demonstração para Anim List Slide
def main():
    print("Executando demo para: Anim List Slide")

if __name__ == '__main__':
    main()
