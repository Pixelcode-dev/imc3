# example.py - script de demonstração para Anim Underline Shift
def main():
    print("Executando demo para: Anim Underline Shift")

if __name__ == '__main__':
    main()
