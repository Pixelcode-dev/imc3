# example.py - script de demonstração para Anim Grid
def main():
    print("Executando demo para: Anim Grid")

if __name__ == '__main__':
    main()
