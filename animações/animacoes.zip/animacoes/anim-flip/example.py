# example.py - script de demonstração para Anim Flip
def main():
    print("Executando demo para: Anim Flip")

if __name__ == '__main__':
    main()
