# example.py - script de demonstração para Anim Text Glitch
def main():
    print("Executando demo para: Anim Text Glitch")

if __name__ == '__main__':
    main()
