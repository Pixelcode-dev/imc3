# example.py - script de demonstração para Anim Gradient Pulse
def main():
    print("Executando demo para: Anim Gradient Pulse")

if __name__ == '__main__':
    main()
