# example.py - script de demonstração para Anim Rotate 3D
def main():
    print("Executando demo para: Anim Rotate 3D")

if __name__ == '__main__':
    main()
