# example.py - script de demonstração para Anim Zoom Out
def main():
    print("Executando demo para: Anim Zoom Out")

if __name__ == '__main__':
    main()
