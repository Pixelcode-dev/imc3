// script.js - comportamento de exemplo para Anim Loading Wave
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Anim Loading Wave'));
});
