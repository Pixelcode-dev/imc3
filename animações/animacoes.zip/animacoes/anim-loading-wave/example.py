# example.py - script de demonstração para Anim Loading Wave
def main():
    print("Executando demo para: Anim Loading Wave")

if __name__ == '__main__':
    main()
