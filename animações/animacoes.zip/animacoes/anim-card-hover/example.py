# example.py - script de demonstração para Anim Card Hover
def main():
    print("Executando demo para: Anim Card Hover")

if __name__ == '__main__':
    main()
