// script.js - comportamento de exemplo para Anim Spark
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Anim Spark'));
});
