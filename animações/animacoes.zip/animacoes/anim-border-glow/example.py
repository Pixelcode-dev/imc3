# example.py - script de demonstração para Anim Border Glow
def main():
    print("Executando demo para: Anim Border Glow")

if __name__ == '__main__':
    main()
