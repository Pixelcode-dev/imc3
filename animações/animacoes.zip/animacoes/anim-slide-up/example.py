# example.py - script de demonstração para Anim Slide Up
def main():
    print("Executando demo para: Anim Slide Up")

if __name__ == '__main__':
    main()
