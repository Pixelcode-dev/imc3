# example.py - script de demonstração para Anim Loop
def main():
    print("Executando demo para: Anim Loop")

if __name__ == '__main__':
    main()
