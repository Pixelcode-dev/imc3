# example.py - script de demonstração para Anim Digital
def main():
    print("Executando demo para: Anim Digital")

if __name__ == '__main__':
    main()
