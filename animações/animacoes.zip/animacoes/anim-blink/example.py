# example.py - script de demonstração para Anim Blink
def main():
    print("Executando demo para: Anim Blink")

if __name__ == '__main__':
    main()
