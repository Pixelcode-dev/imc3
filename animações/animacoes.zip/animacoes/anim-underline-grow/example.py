# example.py - script de demonstração para Anim Underline Grow
def main():
    print("Executando demo para: Anim Underline Grow")

if __name__ == '__main__':
    main()
