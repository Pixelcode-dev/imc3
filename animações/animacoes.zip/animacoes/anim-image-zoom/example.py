# example.py - script de demonstração para Anim Image Zoom
def main():
    print("Executando demo para: Anim Image Zoom")

if __name__ == '__main__':
    main()
