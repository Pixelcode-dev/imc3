# example.py - script de demonstração para Anim Loop Fast
def main():
    print("Executando demo para: Anim Loop Fast")

if __name__ == '__main__':
    main()
