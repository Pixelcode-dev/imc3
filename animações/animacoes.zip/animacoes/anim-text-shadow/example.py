# example.py - script de demonstração para Anim Text Shadow
def main():
    print("Executando demo para: Anim Text Shadow")

if __name__ == '__main__':
    main()
