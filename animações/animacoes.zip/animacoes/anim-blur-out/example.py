# example.py - script de demonstração para Anim Blur Out
def main():
    print("Executando demo para: Anim Blur Out")

if __name__ == '__main__':
    main()
