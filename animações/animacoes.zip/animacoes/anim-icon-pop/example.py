# example.py - script de demonstração para Anim Icon Pop
def main():
    print("Executando demo para: Anim Icon Pop")

if __name__ == '__main__':
    main()
