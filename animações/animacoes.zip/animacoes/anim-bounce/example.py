# example.py - script de demonstração para Anim Bounce
def main():
    print("Executando demo para: Anim Bounce")

if __name__ == '__main__':
    main()
