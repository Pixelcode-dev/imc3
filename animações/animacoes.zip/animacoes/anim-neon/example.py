# example.py - script de demonstração para Anim Neon
def main():
    print("Executando demo para: Anim Neon")

if __name__ == '__main__':
    main()
