# example.py - script de demonstração para Anim Gradient Flow
def main():
    print("Executando demo para: Anim Gradient Flow")

if __name__ == '__main__':
    main()
