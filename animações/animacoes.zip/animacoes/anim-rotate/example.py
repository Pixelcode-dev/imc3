# example.py - script de demonstração para Anim Rotate
def main():
    print("Executando demo para: Anim Rotate")

if __name__ == '__main__':
    main()
