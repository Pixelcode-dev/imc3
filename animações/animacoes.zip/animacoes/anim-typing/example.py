# example.py - script de demonstração para Anim Typing
def main():
    print("Executando demo para: Anim Typing")

if __name__ == '__main__':
    main()
