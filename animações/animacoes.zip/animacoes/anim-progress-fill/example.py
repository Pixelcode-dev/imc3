# example.py - script de demonstração para Anim Progress Fill
def main():
    print("Executando demo para: Anim Progress Fill")

if __name__ == '__main__':
    main()
