# example.py - script de demonstração para Anim Scale
def main():
    print("Executando demo para: Anim Scale")

if __name__ == '__main__':
    main()
