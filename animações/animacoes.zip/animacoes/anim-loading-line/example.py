# example.py - script de demonstração para Anim Loading Line
def main():
    print("Executando demo para: Anim Loading Line")

if __name__ == '__main__':
    main()
