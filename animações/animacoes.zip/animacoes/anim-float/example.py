# example.py - script de demonstração para Anim Float
def main():
    print("Executando demo para: Anim Float")

if __name__ == '__main__':
    main()
