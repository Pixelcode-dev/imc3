# example.py - script de demonstração para Anim Flip Y
def main():
    print("Executando demo para: Anim Flip Y")

if __name__ == '__main__':
    main()
