# example.py - script de demonstração para Anim Wave
def main():
    print("Executando demo para: Anim Wave")

if __name__ == '__main__':
    main()
