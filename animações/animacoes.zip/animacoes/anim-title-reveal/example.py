# example.py - script de demonstração para Anim Title Reveal
def main():
    print("Executando demo para: Anim Title Reveal")

if __name__ == '__main__':
    main()
