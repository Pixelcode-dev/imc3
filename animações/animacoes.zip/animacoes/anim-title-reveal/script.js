// script.js - comportamento de exemplo para Anim Title Reveal
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Anim Title Reveal'));
});
