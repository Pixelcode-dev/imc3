# example.py - script de demonstração para Anim Holo Grid
def main():
    print("Executando demo para: Anim Holo Grid")

if __name__ == '__main__':
    main()
