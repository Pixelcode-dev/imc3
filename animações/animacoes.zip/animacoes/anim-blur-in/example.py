# example.py - script de demonstração para Anim Blur In
def main():
    print("Executando demo para: Anim Blur In")

if __name__ == '__main__':
    main()
