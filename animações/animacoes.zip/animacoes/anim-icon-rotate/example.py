# example.py - script de demonstração para Anim Icon Rotate
def main():
    print("Executando demo para: Anim Icon Rotate")

if __name__ == '__main__':
    main()
