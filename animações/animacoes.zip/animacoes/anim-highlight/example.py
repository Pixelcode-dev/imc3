# example.py - script de demonstração para Anim Highlight
def main():
    print("Executando demo para: Anim Highlight")

if __name__ == '__main__':
    main()
