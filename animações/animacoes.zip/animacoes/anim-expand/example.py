# example.py - script de demonstração para Anim Expand
def main():
    print("Executando demo para: Anim Expand")

if __name__ == '__main__':
    main()
