# example.py - script de demonstração para Anim Shake
def main():
    print("Executando demo para: Anim Shake")

if __name__ == '__main__':
    main()
