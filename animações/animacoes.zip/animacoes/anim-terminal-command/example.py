# example.py - script de demonstração para Anim Terminal Command
def main():
    print("Executando demo para: Anim Terminal Command")

if __name__ == '__main__':
    main()
