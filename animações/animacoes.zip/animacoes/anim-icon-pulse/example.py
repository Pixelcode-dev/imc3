# example.py - script de demonstração para Anim Icon Pulse
def main():
    print("Executando demo para: Anim Icon Pulse")

if __name__ == '__main__':
    main()
