# example.py - script de demonstração para Anim Slide Left
def main():
    print("Executando demo para: Anim Slide Left")

if __name__ == '__main__':
    main()
