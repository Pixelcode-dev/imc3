# example.py - script de demonstração para Anim Progress Bar
def main():
    print("Executando demo para: Anim Progress Bar")

if __name__ == '__main__':
    main()
