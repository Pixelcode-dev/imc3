// script.js - comportamento de exemplo para Anim Progress Bar
document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('actionBtn');
  if (btn) btn.addEventListener('click', () => alert('Ação executada para: Anim Progress Bar'));
});
