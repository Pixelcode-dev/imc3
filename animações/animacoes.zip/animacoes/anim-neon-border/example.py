# example.py - script de demonstração para Anim Neon Border
def main():
    print("Executando demo para: Anim Neon Border")

if __name__ == '__main__':
    main()
