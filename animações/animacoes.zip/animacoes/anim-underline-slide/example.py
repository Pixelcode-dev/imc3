# example.py - script de demonstração para Anim Underline Slide
def main():
    print("Executando demo para: Anim Underline Slide")

if __name__ == '__main__':
    main()
