# example.py - script de demonstração para Anim Terminal
def main():
    print("Executando demo para: Anim Terminal")

if __name__ == '__main__':
    main()
