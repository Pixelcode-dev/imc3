# example.py - script de demonstração para Anim Zoom In
def main():
    print("Executando demo para: Anim Zoom In")

if __name__ == '__main__':
    main()
