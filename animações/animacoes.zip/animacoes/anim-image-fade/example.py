# example.py - script de demonstração para Anim Image Fade
def main():
    print("Executando demo para: Anim Image Fade")

if __name__ == '__main__':
    main()
