# example.py - script de demonstração para Anim Grid Light
def main():
    print("Executando demo para: Anim Grid Light")

if __name__ == '__main__':
    main()
