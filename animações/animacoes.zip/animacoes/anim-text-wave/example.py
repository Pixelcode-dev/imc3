# example.py - script de demonstração para Anim Text Wave
def main():
    print("Executando demo para: Anim Text Wave")

if __name__ == '__main__':
    main()
