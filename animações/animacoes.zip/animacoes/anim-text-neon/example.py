# example.py - script de demonstração para Anim Text Neon
def main():
    print("Executando demo para: Anim Text Neon")

if __name__ == '__main__':
    main()
