# example.py - script de demonstração para Anim Loading Spinner
def main():
    print("Executando demo para: Anim Loading Spinner")

if __name__ == '__main__':
    main()
