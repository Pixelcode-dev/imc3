# example.py - script de demonstração para Anim Border Move
def main():
    print("Executando demo para: Anim Border Move")

if __name__ == '__main__':
    main()
