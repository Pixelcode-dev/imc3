# example.py - script de demonstração para Anim Terminal Blink
def main():
    print("Executando demo para: Anim Terminal Blink")

if __name__ == '__main__':
    main()
