# example.py - script de demonstração para Anim Flash
def main():
    print("Executando demo para: Anim Flash")

if __name__ == '__main__':
    main()
