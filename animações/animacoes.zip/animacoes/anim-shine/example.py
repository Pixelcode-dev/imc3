# example.py - script de demonstração para Anim Shine
def main():
    print("Executando demo para: Anim Shine")

if __name__ == '__main__':
    main()
