# example.py - script de demonstração para Anim Terminal Type
def main():
    print("Executando demo para: Anim Terminal Type")

if __name__ == '__main__':
    main()
