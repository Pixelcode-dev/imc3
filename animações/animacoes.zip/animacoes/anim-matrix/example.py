# example.py - script de demonstração para Anim Matrix
def main():
    print("Executando demo para: Anim Matrix")

if __name__ == '__main__':
    main()
