# example.py - script de demonstração para Anim Particle
def main():
    print("Executando demo para: Anim Particle")

if __name__ == '__main__':
    main()
