# example.py - script de demonstração para Anim Button Press
def main():
    print("Executando demo para: Anim Button Press")

if __name__ == '__main__':
    main()
