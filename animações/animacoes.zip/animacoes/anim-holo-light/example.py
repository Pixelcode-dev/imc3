# example.py - script de demonstração para Anim Holo Light
def main():
    print("Executando demo para: Anim Holo Light")

if __name__ == '__main__':
    main()
