# example.py - script de demonstração para Anim Contract
def main():
    print("Executando demo para: Anim Contract")

if __name__ == '__main__':
    main()
