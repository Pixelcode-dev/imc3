# example.py - script de demonstração para Anim Glow
def main():
    print("Executando demo para: Anim Glow")

if __name__ == '__main__':
    main()
