# example.py - script de demonstração para Anim Button Hover
def main():
    print("Executando demo para: Anim Button Hover")

if __name__ == '__main__':
    main()
