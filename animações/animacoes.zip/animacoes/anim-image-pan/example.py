# example.py - script de demonstração para Anim Image Pan
def main():
    print("Executando demo para: Anim Image Pan")

if __name__ == '__main__':
    main()
