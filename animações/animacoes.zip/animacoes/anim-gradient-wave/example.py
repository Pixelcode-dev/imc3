# example.py - script de demonstração para Anim Gradient Wave
def main():
    print("Executando demo para: Anim Gradient Wave")

if __name__ == '__main__':
    main()
